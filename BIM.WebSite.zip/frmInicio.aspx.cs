﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using Seguridad.Logic.Utilidades;
using Seguridad.DataAccessIntegration;
using Seguridad.Logic.Autenticacion;
using Seguridad.DataAccessIntegration.Autenticacion;
using Seguridad.DataAccessIntegration.Autorizacion;
using Seguridad.Logic.Autorizacion;

//0 Solicitud de módulo y menú
//1 Asignación de TituloPagina
//2 Aplicar reglas de navegación
//2.1 Recuperar variables de navegación en frmLogin.aspx

namespace $safeprojectname$
{
    public partial class frmInicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Label TituloPagina = (Label)this.Master.FindControl("lblNomModulo");
                TituloPagina.Text = "Bienvenido al módulo de Parametrización dinámica SIBAMEX";

                //Page.Title = Application["Nom_Sis"].ToString() + " - Inicio";
                Session["BANNER"] = "S";

                int sintAreaID = Convert.ToInt16(Session["sintAreaID"]);

                if (!IsPostBack)
                {
                    if (sintAreaID == 1)
                    {
                        Response.Redirect("~/frmAutoriza_PS.aspx");
                    }
                    if (sintAreaID == -1)
                    {
                        Response.Redirect("~/frmCaptura_PS.aspx");
                    }
                }   

                ////string PerfilID = Convert.ToInt16(Session["PerfilID"]);
                //string User = (string)Session["User"];
                //string Perfil = (string)Session["Perfil"];
                //string UserName = (string)Session["UserName"];
                //string Puesto = (string)Session["Puesto"];
                //string DatosSesion = (string)Session["DatosSesion"];
                //string DatosInformatvos = (string)Session["DatosInformatvos"];

                ////string sintSistemaID = (int)Session["sintSistemaID"];
                //// Almacenamos el token
                //string token = (string)Session["token"];
                ////string UserId = Convert.ToInt16(Session["UserId"]);

            }
        }
    }
}