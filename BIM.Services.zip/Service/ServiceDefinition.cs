﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using BIM.BussinesEntities;
using BIM.Logic;

namespace $safeprojectname$
{
    public class ServiceDefinition : IServiceContract
    {
        public void operation1(int arg1, string arg2)
        {
            try
            {
                
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
    }
}
