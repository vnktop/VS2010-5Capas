﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using BIM.BussinesEntities;

namespace $safeprojectname$
{
    [ServiceContract]
    interface IServiceContract
    {
        [OperationContract]
        void operation1(int arg1, string arg2);
    }
}
